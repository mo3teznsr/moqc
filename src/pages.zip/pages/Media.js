
import React, { Component } from "react";
import { KeyboardAvoidingView, TouchableOpacity, View, Image, Text } from "react-native";
import { Button } from "react-native-paper";
import WebView from "react-native-webview";
import Axios from 'axios'
import i18n from "../i18n";




export default class Media extends Component {
    constructor(props) {
        super(props);
        this.state = {
            network: true
        }
        this.getConnectionInfo()
    }

    async getConnectionInfo() {
        const response = await Axios.get(`https://staging.moqc.ae/api/equran_list`);
        if (response.status === 200) {
            this.setState({ network: true })
        }
        else {
            this.setState({network:false})
        }
    }

    render() {
        return (

            <View style={{flex: 1 }}>

                {this.state.network ?

                    <WebView source={{ uri: 'https://staging.moqc.ae/media' }} /> :

                    <View style={{flex:1, justifyContent:'center',alignItems:'center', alignContent:'center'}}>
                        <Text>{i18n.t("You have no Internet Connection")}</Text>
                        <Button style={{backgroundColor:'#31314F', color:'#CB565D'}} onPress={() => this.getConnectionInfo}><Text style={{color:'#CB565D'}}>{i18n.t('Please Retry')}</Text></Button>
                    </View>
                }

                {/* <View style={{position: 'absolute',  right: 20, bottom: 90,zIndex:10}}>
                <TouchableOpacity onPress={() => this.props.navigation.navigate("Landing")}>
                    <Image source={require('../assets/moqc.png')} style={{width:44,height:44,borderRadius:44,borderWidth:1,borderColor:"#e3e3e3"}} ></Image>
                </TouchableOpacity>
            </View> */}
            </View>

        )
    }
}