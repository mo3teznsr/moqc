import { Text, View } from "react-native";
import React, {Component} from "react";



export default class List extends Component{
    constructor(props)
    {
        super(props)
    }

    render()
    {
        return (<View>
            <Text>List</Text>
        </View>)
    }
}