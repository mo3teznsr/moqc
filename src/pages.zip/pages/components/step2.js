

import { Spinner } from "native-base";
import React, {Component, useEffect, useState} from "react";
import { Image, Text, TouchableOpacity, View ,TextInput,StyleSheet, Pressable, Modal, Button} from "react-native";
import Select from "./select";
import DateTimePicker from '@react-native-community/datetimepicker';
import moment from 'moment';
import { withTranslation } from "react-i18next";

const Step2=(props)=>{

const [gender,setGender]=useState('')
const [showCountries,setShowCountries]=useState(false)
const [showCourse,setShowCourse]=useState(false)
const [showResidance,setShowResidance]=useState(false)
const [showQualification,setShowQualification]=useState(false)
const [countries,setCountries]=useState([])
const [showDob,setShowDob]=useState(false)
const [showJob,setShowJob]=useState(false)
const [showLocation,setShowLocation]=useState(false)
const [dob,setDob]=useState(Date())
const [qualifications,setQuailifications]=useState([])
const [jobs,setJobs]=useState([])
const [error,setError]=useState(false)

useEffect(()=>{

 
},[])
const {t, i18n} = props;

    return ( <View>
   

      <Text style={{textAlign:"center",marginVertical:15,fontSize:25,fontWeight:"600"}}>{t('Personal Information')}</Text>
          
          
        <Text style={styles.label}>{t("Your Full name")}</Text>
      <TextInput style={styles.input} value={props.data.first_name} onChangeText={(val)=>props.update({first_name:val})} />
      
      <Text style={styles.label}>{t("Nationality")}</Text>
     

      <Select
      list={props.data.countries}
      title={t('Nationality')}
      show={showCountries}
      field="id"
      selected={props.data.nationality}
      open={()=>setShowCountries(true)}
      onSelect={(item)=>{
        setShowCountries(false)
        
        props.update({nationality:item})
        console.log(item)}}
      render={i18n.language=='ar'?'country_name_ar': 'country_name'}
      close={()=>setShowCountries(false)} />

      
      
      <Text style={styles.label}>{ t("Date of Birth")}</Text>
      <Pressable onPress={()=>setShowDob(true)}>
        <View style={{...styles.input,flexDirection:"row",justifyContent:"space-between"}}>
        <Text style={{fontSize:20}}>{props.data.dob} </Text>
        <Image source={require("../../assets/calendar.png")} style={{width:25,height:25}}  />
        </View>
       
        </Pressable>
      {showDob? <DateTimePicker
                                 
                                   value={props.data.dob?new Date(props.data.dob):new Date()}
                                    mode='date'
                                    display="calendar"
                                    onChange={(val,date)=>{
                                      setShowDob( false)
                                      props.update({dob:moment( date).format("YYYY-MM-DD")})
                                     
                                        console.log(date,moment(date).format("YYYY-MM-DD"))}}
                                />:<Text></Text>}

      <Text style={styles.label}>{t('Your qualification')}</Text>
      <Select
      list={props.data.qualifications}
      title={t('Your qualification')}
      show={showQualification}
      field="id"
      selected={props.data.qualification_id}
      open={()=>setShowQualification(true)}
      onSelect={(item)=>{
        setShowQualification(false)
        
        props.update({qualification_id:item})
        console.log(item)}}
      render={i18n.language=='ar'?'name_ar': 'name_en'}
      close={()=>setShowQualification(false)} />

      <Text style={styles.label}>{t('Contact Number')}</Text>
      <TextInput style={styles.input}  value={props.data.contact_number} onChangeText={(val)=>props.update({contact_number:val})} keyboardType="phone-pad" />


      <Text style={styles.label}>{t('Counrty of Residance')}</Text>
      <Select
      list={props.data.countries}
      title={t('Counrty of Residance')}
      show={showResidance}
      field="id"
      selected={props.data.country}
      open={()=>setShowResidance(true)}
      onSelect={(item)=>{
        setShowResidance(false)
        
        props.update({nationality:item})
        console.log(item)}}
      render={i18n.language=='ar'?'country_name_ar': 'country_name'}
      close={()=>setShowResidance(false)} />

      <Text style={styles.label}>{t('Email')}</Text>
      <TextInput value={props.data.email} style={styles.input} onChangeText={(val)=>props.update({email:val})} />

      <Text style={styles.label}>{t('Your Job')}</Text>
      <Select
      list={props.data.jobs}
      title={t('Your Job')}
      show={showJob}
      field="id"
      selected={props.data.job_id}
      open={()=>setShowJob(true)}
      onSelect={(item)=>{
        setShowJob(false)
        
        props.update({job_id:item})
        console.log(item)}}
      render={i18n.language=='ar'?'name_ar': 'name_en'}
      close={()=>setShowJob(false)} />

<Text style={styles.label}>{t('Where did you find us?')}</Text>
      <Select
      list={props.data.locations}
      title={t('Where did you find us?')}
      show={showLocation}
      field="id"
      selected={props.data.location_id}
      open={()=>setShowLocation(true)}
      onSelect={(item)=>{
        setShowLocation(false)
        props.update({location_id:item})
        console.log(item)}}
      render={i18n.language=='ar'?'name_ar': 'name_en'}
      close={()=>setShowLocation(false)} />

      <Text style={styles.label}>{t("Memorized Juz'")}</Text>
      <TextInput value={props.data.memorized.toString()} keyboardType="number-pad"
      onChangeText={(val)=>props.update({memorized:val})} style={styles.input} />

<Text style={styles.label}>{t('Course')}</Text>
      <Select
      list={props.data.courses}
      title={t('Course')}
      show={showCourse}
      field="id"
      selected={props.data.course_id}
      open={()=>setShowCourse(true)}
      onSelect={(item)=>{
        setShowCourse(false)
        props.update({course_id:item})
        console.log(item)}}
      render={i18n.language=='ar'?'course_name_ar': 'course_name_en'}
      close={()=>setShowCourse(false)} />

     {error? <View style={{padding:18,borderRadius:15,backgroundColor:"#eb445a"}}>
        <Text style={{color:"#fff",fontSize:18,fontWeight:"600"}}>{t('Please fill all records')}</Text>
      </View>:<View></View>}

<View style={{flex:1,flexDirection:"row",justifyContent:"center",alignContent:"center",marginTop:5,marginBottom:5}}>
                            <Pressable onPress={() => {
                            //  console.log(props.data.first_name,props.data.nationality,props.data.dob,props.data.qualification_id,props.data.contact_number,props.data.country,props.data.email,props.data.job_id,props.data.location_id,props.data.course_id)
                              if(props.data.first_name&&props.data.nationality&&props.data.dob&&props.data.qualification_id&&props.data.contact_number&&props.data.country&&props.data.email&&props.data.job_id&&props.data.location_id&&props.data.course_id)
                              {
                                
                                setError(false)
                                props.update({active_step:2})

                              }
                              else {
                                setError(true)
                              }

                              
                            }} style={{width:120,height:50,borderRadius:30,justifyContent:"center",alignContent:"center",backgroundColor:"#31314f"}}>
                                <Text style={{textAlign:"center",color:"#fff",fontWeight:"500"}}>
                                    {t('Next')} 
                                </Text>
                              
                            </Pressable>

                        </View>
    </View>);
}

export default  withTranslation()(Step2);

const styles=StyleSheet.create({
    label:{marginHorizontal:10,fontSize:18},
    input:{borderBottomWidth:1,paddingHorizontal:15,marginBottom:10,color:"#000"}
})